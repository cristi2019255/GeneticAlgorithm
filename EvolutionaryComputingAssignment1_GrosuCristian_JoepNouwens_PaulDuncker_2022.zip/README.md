# GeneticAlgorithm
A simple genetic algorithm for bit stirng optimisation